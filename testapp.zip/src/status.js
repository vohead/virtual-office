export default {
  NOT_STARTED: "not started",
  IN_PROGRESS: "in progress",
  FAILED: "failed",
  FINISHED: "finished"
}